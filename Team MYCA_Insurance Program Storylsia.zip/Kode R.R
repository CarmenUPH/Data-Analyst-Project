setwd("D:/SEM 6/CAP")
library(readxl)
rm(list=ls())
data_hazard =read_excel("Hazard2.xlsx")
data_hazard=subset(data_hazard,data_hazard$Year!=1960&data_hazard$Year!=1961)

data_hazard_1=subset(data_hazard,Region==1)
data_hazard_2=subset(data_hazard,Region==2)
data_hazard_3=subset(data_hazard,Region==3)
data_hazard_4=subset(data_hazard,Region==4)
data_hazard_5=subset(data_hazard,Region==5)
data_hazard_6=subset(data_hazard,Region==6)

#Propdamage proporsi banyak rumah yang ditempati orang dibagi banyak orang per rumah
data_hazard_1[,8]=data_hazard_1[,8]*1904073/2791896
data_hazard_2[,8]=data_hazard_2[,8]*1862514/2523732
data_hazard_3[,8]=data_hazard_3[,8]*1323096/2212536
data_hazard_4[,8]=data_hazard_4[,8]*333680/496548
data_hazard_5[,8]=data_hazard_5[,8]*365451/566592
data_hazard_6[,8]=data_hazard_6[,8]*102693/135480

gaji=read_excel("GAJI.xlsx")
gaji1=gaji[,c(1,2)]
data_hazard_1=merge(gaji1,data_hazard_1,by="Year")

gaji2=gaji[,c(1,3)]
data_hazard_2=merge(gaji2,data_hazard_2,by="Year")

gaji3=gaji[,c(1,4)]
data_hazard_3=merge(gaji3,data_hazard_3,by="Year")

gaji4=gaji[,c(1,5)]
data_hazard_4=merge(gaji4,data_hazard_4,by="Year")

gaji5=gaji[,c(1,6)]
data_hazard_5=merge(gaji5,data_hazard_5,by="Year")

gaji6=gaji[,c(1,7)]
data_hazard_6=merge(gaji6,data_hazard_6,by="Year")

#Fatalities 1 bulan gaji
data_hazard_1[,7]=data_hazard_1[,7]+10/365*data_hazard_1$R1
data_hazard_2[,7]=data_hazard_2[,7]+10/365*data_hazard_2$R2
data_hazard_3[,7]=data_hazard_3[,7]+10/365*data_hazard_3$R3
data_hazard_4[,7]=data_hazard_4[,7]+10/365*data_hazard_4$R4
data_hazard_5[,7]=data_hazard_5[,7]+10/365*data_hazard_5$R5
data_hazard_6[,7]=data_hazard_6[,7]+10/365*data_hazard_6$R6

#injuries 7 hari kerja 
data_hazard_1[,8]=data_hazard_1[,8]+5/365*data_hazard_1$R1
data_hazard_2[,8]=data_hazard_2[,8]+5/365*data_hazard_2$R2
data_hazard_3[,8]=data_hazard_3[,8]+5/365*data_hazard_3$R3
data_hazard_4[,8]=data_hazard_4[,8]+5/365*data_hazard_4$R4
data_hazard_5[,8]=data_hazard_5[,8]+5/365*data_hazard_5$R5
data_hazard_6[,8]=data_hazard_6[,8]+5/365*data_hazard_6$R6

data_hazard_1$Severity=0.5*data_hazard_1$PropertyDamage+data_hazard_1$Fatalities+data_hazard_1$Injuries
data_hazard_2$Severity=0.5*data_hazard_2$PropertyDamage+data_hazard_2$Fatalities+data_hazard_2$Injuries
data_hazard_3$Severity=0.5*data_hazard_3$PropertyDamage+data_hazard_3$Fatalities+data_hazard_3$Injuries
data_hazard_4$Severity=0.5*data_hazard_4$PropertyDamage+data_hazard_4$Fatalities+data_hazard_4$Injuries
data_hazard_5$Severity=0.5*data_hazard_5$PropertyDamage+data_hazard_5$Fatalities+data_hazard_5$Injuries
data_hazard_6$Severity=0.5*data_hazard_6$PropertyDamage+data_hazard_6$Fatalities+data_hazard_6$Injuries

minor_1=quantile(data_hazard_1$Severity,0.25)
major_1=quantile(data_hazard_1$Severity,0.9)

minor_2=quantile(data_hazard_2$Severity,0.25)
major_2=quantile(data_hazard_2$Severity,0.9)

minor_3=quantile(data_hazard_3$Severity,0.25)
major_3=quantile(data_hazard_3$Severity,0.9)

minor_4=quantile(data_hazard_4$Severity,0.25)
major_4=quantile(data_hazard_4$Severity,0.9)

minor_5=quantile(data_hazard_5$Severity,0.25)
major_5=quantile(data_hazard_5$Severity,0.9)

minor_6=quantile(data_hazard_6$Severity,0.25)
major_6=quantile(data_hazard_6$Severity,0.9)

df=data.frame(Minor=c(minor_1,minor_2,minor_3,minor_4,minor_5,minor_6),
              Major=c(major_1,major_2,major_3,major_4,major_5,major_6))
rownames(df)=c("Region1","Region2","Region3","Region4","Region5","Region6")

data_hazard_1=data.frame(data_hazard_1,Status=ifelse(data_hazard_1$Severity<df[1,1],"Minor",
                                            ifelse(data_hazard_1$Severity<df[1,2],"Medium","Major")))
data_hazard_2=data.frame(data_hazard_2,Status=ifelse(data_hazard_2$Severity<df[2,1],"Minor",
                                            ifelse(data_hazard_2$Severity<df[2,2],"Medium","Major")))
data_hazard_3=data.frame(data_hazard_3,Status=ifelse(data_hazard_3$Severity<df[3,1],"Minor",
                                            ifelse(data_hazard_3$Severity<df[3,2],"Medium","Major")))
data_hazard_4=data.frame(data_hazard_4,Status=ifelse(data_hazard_4$Severity<df[4,1],"Minor",
                                            ifelse(data_hazard_4$Severity<df[4,2],"Medium","Major")))
data_hazard_5=data.frame(data_hazard_5,Status=ifelse(data_hazard_5$Severity<df[5,1],"Minor",
                                            ifelse(data_hazard_5$Severity<df[5,2],"Medium","Major")))
data_hazard_6=data.frame(data_hazard_6,Status=ifelse(data_hazard_6$Severity<df[6,1],"Minor",
                                              ifelse(data_hazard_6$Severity<df[6,2],"Medium","Major")))

#interest
data_interest =read_excel("Interest.xlsx")
library(zoo)
library(forecast)
data_interest=na.approx(data_interest)
ts_1=ts(data_interest[,2],start = c(1962,1))
ts_2=ts(data_interest[,3],start = c(1962,1))
ts_3=ts(data_interest[,4],start = c(1962,1))
ts_4=ts(data_interest[,5],start = c(1962,1))
ts_model_1=auto.arima(ts_1)
ts_model_2=auto.arima(ts_2)
ts_model_3=auto.arima(ts_3)
ts_model_4=auto.arima(ts_4)
prediction_1=forecast(ts_model_1)
prediction_2=forecast(ts_model_2)
prediction_3=forecast(ts_model_3)
prediction_4=forecast(ts_model_4)
plot(prediction_1)
lines(ts_1,col="blue")
plot(prediction_2)
lines(ts_2,col="blue")
plot(prediction_3)
lines(ts_3,col="blue")
plot(prediction_4)
lines(ts_4,col="blue")
summary(prediction_1)
summary(prediction_2)
summary(prediction_3)
summary(prediction_4)

years=seq(1960,2050)
values1=10^-67*exp(0.0841*years)
values2=3*10^-128*exp(0.1528*years)
values3=5*10^-31*exp(0.0421*years)
values4=6*10^53*exp(-0.054*years)
values5=2*10^17*exp(-0.013*years)
values6=2*10^19*exp(-0.016*years)
penduduk=data.frame(years,values1,values2,values3
                    ,values4,values5,values6)

Minor_1=sum(data_hazard_1$Status=="Minor")/59
Medium_1=sum(data_hazard_1$Status=="Medium")/59
Major_1=sum(data_hazard_1$Status=="Major")/59
Minor_2=sum(data_hazard_2$Status=="Minor")/59
Medium_2=sum(data_hazard_2$Status=="Medium")/59
Major_2=sum(data_hazard_2$Status=="Major")/59
Minor_3=sum(data_hazard_3$Status=="Minor")/59
Medium_3=sum(data_hazard_3$Status=="Medium")/59
Major_3=sum(data_hazard_3$Status=="Major")/59
Minor_4=sum(data_hazard_4$Status=="Minor")/59
Medium_4=sum(data_hazard_4$Status=="Medium")/59
Major_4=sum(data_hazard_4$Status=="Major")/59
Minor_5=sum(data_hazard_5$Status=="Minor")/59
Medium_5=sum(data_hazard_5$Status=="Medium")/59
Major_5=sum(data_hazard_5$Status=="Major")/59
Minor_6=sum(data_hazard_6$Status=="Minor")/59
Medium_6=sum(data_hazard_6$Status=="Medium")/59
Major_6=sum(data_hazard_6$Status=="Major")/59


library(dplyr)
library(tidyr)

data_hazard_1$Status=factor(data_hazard_1$Status)
data_hazard_2$Status=factor(data_hazard_2$Status)
data_hazard_3$Status=factor(data_hazard_3$Status)
data_hazard_4$Status=factor(data_hazard_4$Status)
data_hazard_5$Status=factor(data_hazard_5$Status)
data_hazard_6$Status=factor(data_hazard_6$Status)


data_hazard_1[,8]=data_hazard_1[,8]-5/365*data_hazard_1$R1
data_hazard_2[,8]=data_hazard_2[,8]-5/365*data_hazard_2$R2
data_hazard_3[,8]=data_hazard_3[,8]-5/365*data_hazard_3$R3
data_hazard_4[,8]=data_hazard_4[,8]-5/365*data_hazard_4$R4
data_hazard_5[,8]=data_hazard_5[,8]-5/365*data_hazard_5$R5
data_hazard_6[,8]=data_hazard_6[,8]-5/365*data_hazard_6$R6

data_hazard_1=data_hazard_1[,-2]
data_hazard_2=data_hazard_2[,-2]
data_hazard_3=data_hazard_3[,-2]
data_hazard_4=data_hazard_4[,-2]
data_hazard_5=data_hazard_5[,-2]
data_hazard_6=data_hazard_6[,-2]


data_hazard1=data_hazard_1 %>%
  group_by(Year, Status,Duration,Injuries) %>%
  summarize(count = n(),total_severity = sum(Severity)) %>%
  pivot_wider(names_from = Status, values_from = count, values_fill = 0)

data_hazard2=data_hazard_2 %>%
  group_by(Year, Status,Duration,Injuries) %>%
  summarize(count = n(),total_severity = sum(Severity)) %>%
  pivot_wider(names_from = Status, values_from = count, values_fill = 0)

data_hazard3=data_hazard_3 %>%
  group_by(Year, Status,Duration,Injuries) %>%
  summarize(count = n(),total_severity = sum(Severity)) %>%
  pivot_wider(names_from = Status, values_from = count, values_fill = 0)

data_hazard4=data_hazard_4 %>%
  group_by(Year, Status,Duration,Injuries) %>%
  summarize(count = n(),total_severity = sum(Severity)) %>%
  pivot_wider(names_from = Status, values_from = count, values_fill = 0)

data_hazard5=data_hazard_5 %>%
  group_by(Year, Status,Duration,Injuries) %>%
  summarize(count = n(),total_severity = sum(Severity)) %>%
  pivot_wider(names_from = Status, values_from = count, values_fill = 0)

data_hazard6=data_hazard_6 %>%
  group_by(Year, Status,Duration,Injuries) %>%
  summarize(count = n(),total_severity = sum(Severity)) %>%
  pivot_wider(names_from = Status, values_from = count, values_fill = 0)

inflasi=read_xlsx("cihuy.xlsx")
data_hazard1_med=subset(data_hazard1,data_hazard1$Medium!=0)
inflasi_med=inflasi[,c(1,4)]
a1=merge(inflasi_med,data_hazard1_med,by="Year")
a1$total_severity=a1$total_severity+a1$Med_med*a1$Medium*a1$Injuries

data_hazard1_maj=subset(data_hazard1,data_hazard1$Major!=0)
inflasi_maj=inflasi[,c(1,5)]
b1=merge(inflasi_maj,data_hazard1_maj,by="Year")
b1$total_severity=b1$total_severity+b1$Major_med*b1$Major*b1$Injuries

data_hazard2_med=subset(data_hazard2,data_hazard2$Medium!=0)
a2=merge(inflasi_med,data_hazard2_med,by="Year")
a2$total_severity=a2$total_severity+a2$Med_med*a2$Medium*a2$Injuries

data_hazard2_maj=subset(data_hazard2,data_hazard2$Major!=0)
b2=merge(inflasi_maj,data_hazard2_maj,by="Year")
b2$total_severity=b2$total_severity+b2$Major_med*b2$Major*b2$Injuries

data_hazard3_med=subset(data_hazard3,data_hazard3$Medium!=0)
a3=merge(inflasi_med,data_hazard3_med,by="Year")
a3$total_severity=a3$total_severity+a3$Med_med*a3$Medium*a3$Injuries

data_hazard3_maj=subset(data_hazard3,data_hazard3$Major!=0)
b3=merge(inflasi_maj,data_hazard3_maj,by="Year")
b3$total_severity=b3$total_severity+b3$Major_med*b3$Major*b3$Injuries

data_hazard4_med=subset(data_hazard4,data_hazard4$Medium!=0)
a4=merge(inflasi_med,data_hazard4_med,by="Year")
a4$total_severity=a4$total_severity+a4$Med_med*a4$Medium*a4$Injuries

data_hazard4_maj=subset(data_hazard4,data_hazard4$Major!=0)
b4=merge(inflasi_maj,data_hazard4_maj,by="Year")
b4$total_severity=b4$total_severity+b4$Major_med*b4$Major*b4$Injuries

data_hazard5_med=subset(data_hazard5,data_hazard5$Medium!=0)
a5=merge(inflasi_med,data_hazard5_med,by="Year")
a5$total_severity=a5$total_severity+a5$Med_med*a5$Medium*a5$Injuries

data_hazard5_maj=subset(data_hazard5,data_hazard5$Major!=0)
b5=merge(inflasi_maj,data_hazard5_maj,by="Year")
b5$total_severity=b5$total_severity+b5$Major_med*b5$Major*b5$Injuries

data_hazard6_med=subset(data_hazard6,data_hazard6$Medium!=0)
a6=merge(inflasi_med,data_hazard6_med,by="Year")
a6$total_severity=a6$total_severity+a6$Med_med*a6$Medium*a6$Injuries

data_hazard6_maj=subset(data_hazard6,data_hazard6$Major!=0)
b6=merge(inflasi_maj,data_hazard6_maj,by="Year")
b6$total_severity=b6$total_severity+b6$Major_med*b6$Major*b6$Injuries

inflasi_med=inflasi[,c(1,6)]
inflasi_maj=inflasi[,c(1,7)]
a1=merge(inflasi_med,a1,by="Year")
a1$total_severity=a1$total_severity+a1$Med_trans*a1$Medium*a1$Duration

b1=merge(inflasi_maj,b1,by="Year")
b1$total_severity=b1$total_severity+b1$Major_trans*b1$Major*b1$Duration

a2=merge(inflasi_med,a2,by="Year")
a2$total_severity=a2$total_severity+a2$Med_trans*a2$Medium*a2$Duration

b2=merge(inflasi_maj,b2,by="Year")
b2$total_severity=b2$total_severity+b2$Major_trans*b2$Major*b2$Duration

a3=merge(inflasi_med,a3,by="Year")
a3$total_severity=a3$total_severity+a3$Med_trans*a3$Medium*a3$Duration

b3=merge(inflasi_maj,b3,by="Year")
b3$total_severity=b3$total_severity+b3$Major_trans*b3$Major*b3$Duration

a4=merge(inflasi_med,a4,by="Year")
a4$total_severity=a4$total_severity+a4$Med_trans*a4$Medium*a4$Duration

b4=merge(inflasi_maj,b4,by="Year")
b4$total_severity=b4$total_severity+b4$Major_trans*b4$Major*b4$Duration

a5=merge(inflasi_med,a5,by="Year")
a5$total_severity=a5$total_severity+a5$Med_trans*a5$Medium*a5$Duration

b5=merge(inflasi_maj,b5,by="Year")
b5$total_severity=b5$total_severity+b5$Major_trans*b5$Major*b5$Duration

a6=merge(inflasi_med,a6,by="Year")
a6$total_severity=a6$total_severity+a6$Med_trans*a6$Medium*a6$Duration

b6=merge(inflasi_maj,b6,by="Year")
b6$total_severity=b6$total_severity+b6$Major_trans*b6$Major*b6$Duration

c1=subset(data_hazard1,data_hazard1$Minor!=0)
c2=subset(data_hazard2,data_hazard2$Minor!=0)
c3=subset(data_hazard3,data_hazard3$Minor!=0)
c4=subset(data_hazard4,data_hazard4$Minor!=0)
c5=subset(data_hazard5,data_hazard5$Minor!=0)
c6=subset(data_hazard6,data_hazard6$Minor!=0)

a1=a1[,-c(2,3)]
a2=a2[,-c(2,3)]
a3=a3[,-c(2,3)]
a4=a4[,-c(2,3)]
a5=a5[,-c(2,3)]
a6=a6[,-c(2,3)]
b1=b1[,-c(2,3)]
b2=b2[,-c(2,3)]
b3=b3[,-c(2,3)]
b4=b4[,-c(2,3)]
b5=b5[,-c(2,3)]
b6=b6[,-c(2,3)]

a1=a1 %>%
  group_by(Year,Major,Minor) %>%
  summarize(Medium = sum(Medium),total_severity = sum(total_severity))
b1=b1 %>%
  group_by(Year,Medium,Minor) %>%
  summarize(Major = sum(Major),total_severity = sum(total_severity))
a2=a2 %>%
  group_by(Year,Major,Minor) %>%
  summarize(Medium = sum(Medium),total_severity = sum(total_severity))
b2=b2 %>%
  group_by(Year,Medium,Minor) %>%
  summarize(Major = sum(Major),total_severity = sum(total_severity))
a3=a3 %>%
  group_by(Year,Major,Minor) %>%
  summarize(Medium = sum(Medium),total_severity = sum(total_severity))
b3=b3 %>%
  group_by(Year,Medium,Minor) %>%
  summarize(Major = sum(Major),total_severity = sum(total_severity))
a4=a4 %>%
  group_by(Year,Major,Minor) %>%
  summarize(Medium = sum(Medium),total_severity = sum(total_severity))
b4=b4 %>%
  group_by(Year,Medium,Minor) %>%
  summarize(Major = sum(Major),total_severity = sum(total_severity))
a5=a5 %>%
  group_by(Year,Major,Minor) %>%
  summarize(Medium = sum(Medium),total_severity = sum(total_severity))
b5=b5 %>%
  group_by(Year,Medium,Minor) %>%
  summarize(Major = sum(Major),total_severity = sum(total_severity))
a6=a6 %>%
  group_by(Year,Major,Minor) %>%
  summarize(Medium = sum(Medium),total_severity = sum(total_severity))
b6=b6 %>%
  group_by(Year,Medium,Minor) %>%
  summarize(Major = sum(Major),total_severity = sum(total_severity))
c1=c1 %>%
  group_by(Year,Medium,Major) %>%
  summarize(Minor = sum(Minor),total_severity = sum(total_severity))
c2=c2 %>%
  group_by(Year,Medium,Major) %>%
  summarize(Minor = sum(Minor),total_severity = sum(total_severity))
c3=c3 %>%
  group_by(Year,Medium,Major) %>%
  summarize(Minor = sum(Minor),total_severity = sum(total_severity))
c4=c4 %>%
  group_by(Year,Medium,Major) %>%
  summarize(Minor = sum(Minor),total_severity = sum(total_severity))
c5=c5 %>%
  group_by(Year,Medium,Major) %>%
  summarize(Minor = sum(Minor),total_severity = sum(total_severity))
c6=c6 %>%
  group_by(Year,Medium,Major) %>%
  summarize(Minor = sum(Minor),total_severity = sum(total_severity))

data_hazard1=rbind(a1,b1,c1)
data_hazard2=rbind(a2,b2,c2)
data_hazard3=rbind(a3,b3,c3)
data_hazard4=rbind(a4,b4,c4)
data_hazard5=rbind(a5,b5,c5)
data_hazard6=rbind(a6,b6,c6)

data_hazard1=data_hazard1[order(data_hazard1$Year),]
data_hazard2=data_hazard2[order(data_hazard2$Year),]
data_hazard3=data_hazard3[order(data_hazard3$Year),]
data_hazard4=data_hazard4[order(data_hazard4$Year),]
data_hazard5=data_hazard5[order(data_hazard5$Year),]
data_hazard6=data_hazard6[order(data_hazard6$Year),]

data_hazard1$total_severity=data_hazard1$total_severity*1.0384^10
data_hazard2$total_severity=data_hazard2$total_severity*1.0384^10
data_hazard3$total_severity=data_hazard3$total_severity*1.0384^10
data_hazard4$total_severity=data_hazard4$total_severity*1.0384^10
data_hazard5$total_severity=data_hazard5$total_severity*1.0384^10
data_hazard6$total_severity=data_hazard6$total_severity*1.0384^10

#bulman region_1
m_minor=sum(data_hazard1$Minor)
m_med=sum(data_hazard1$Medium)
m_major=sum(data_hazard1$Major)
m_tot=m_minor+m_med+m_major

data_hazard1$xij_minor=ifelse(data_hazard1$Minor != 0, 
                              data_hazard1$total_severity/data_hazard1$Minor,0)
data_hazard1$xij_med=ifelse(data_hazard1$Medium != 0, 
                            data_hazard1$total_severity/data_hazard1$Medium,0)
data_hazard1$xij_major=ifelse(data_hazard1$Major != 0, 
                              data_hazard1$total_severity/data_hazard1$Major,0)

Xbar_minor=1/m_minor*(sum(data_hazard1$Minor*data_hazard1$xij_minor))
Xbar_med=1/m_med*(sum(data_hazard1$Medium*data_hazard1$xij_med))
Xbar_major=1/m_major*(sum(data_hazard1$Major*data_hazard1$xij_major))
Xbar=sum(data_hazard1$total_severity)/m_tot

V_minor=1/(m_minor-1)*(sum(data_hazard1$Minor*(data_hazard1$xij_minor-Xbar_minor)^2))
V_med=1/(m_med-1)*(sum(data_hazard1$Medium*(data_hazard1$xij_med-Xbar_med)^2))
V_major=1/(m_major-1)*(sum(data_hazard1$Major*(data_hazard1$xij_major-Xbar_major)^2))
V=1/(m_tot-3)*((m_minor-1)*V_minor+(m_med-1)*V_med+(m_major-1)*V_major)
a=m_tot/(m_tot^2-m_minor^2-m_med^2-m_major^2)*((m_minor*(Xbar_minor-Xbar)^2+
  m_med*(Xbar_med-Xbar)^2+m_major*(Xbar_major-Xbar)^2)-2*V)

Z_minor=m_minor/(m_minor+V/a)
Z_med=m_med/(m_med+V/a)
Z_major=m_major/(m_major+V/a)

P1_minor=2.960*(Z_minor*Xbar_minor+(1-Z_minor)*Xbar)
P1_med=7.704*(Z_med*Xbar_med+(1-Z_med)*Xbar)
P1_major=1.196*(Z_major*Xbar_major+(1-Z_major)*Xbar)
P1=P1_minor+P1_med+P1_major
  
#bulman region_2
m_minor=sum(data_hazard2$Minor)
m_med=sum(data_hazard2$Medium)
m_major=sum(data_hazard2$Major)
m_tot=m_minor+m_med+m_major

data_hazard2$xij_minor=ifelse(data_hazard2$Minor != 0, data_hazard2$total_severity/data_hazard2$Minor,0)
data_hazard2$xij_med=ifelse(data_hazard2$Medium != 0, data_hazard2$total_severity/data_hazard2$Medium,0)
data_hazard2$xij_major=ifelse(data_hazard2$Major != 0, data_hazard2$total_severity/data_hazard2$Major,0)

Xbar_minor=1/m_minor*(sum(data_hazard2$Minor*data_hazard2$xij_minor))
Xbar_med=1/m_med*(sum(data_hazard2$Medium*data_hazard2$xij_med))
Xbar_major=1/m_major*(sum(data_hazard2$Major*data_hazard2$xij_major))
Xbar=sum(data_hazard2$total_severity)/m_tot

V_minor=1/(m_minor-1)*(sum(data_hazard2$Minor*(data_hazard2$xij_minor-Xbar_minor)^2))
V_med=1/(m_med-1)*(sum(data_hazard2$Medium*(data_hazard2$xij_med-Xbar_med)^2))
V_major=1/(m_major-1)*(sum(data_hazard2$Major*(data_hazard2$xij_major-Xbar_major)^2))
V=1/(m_tot-3)*((m_minor-1)*V_minor+(m_med-1)*V_med+(m_major-1)*V_major)
a=m_tot/(m_tot^2-m_minor^2-m_med^2-m_major^2)*((m_minor*(Xbar_minor-Xbar)^2+
                                                  m_med*(Xbar_med-Xbar)^2+m_major*(Xbar_major-Xbar)^2)-2*V)
Z_minor=m_minor/(m_minor+V/a)
Z_med=m_med/(m_med+V/a)
Z_major=m_major/(m_major+V/a)

P2_minor=3.713*(Z_minor*Xbar_minor+(1-Z_minor)*Xbar)
P2_med=9.654*(Z_med*Xbar_med+(1-Z_med)*Xbar)
P2_major=1.485*(Z_major*Xbar_major+(1-Z_major)*Xbar)
P2=P2_minor+P2_med+P2_major 

#bulman region_3
m_minor=sum(data_hazard3$Minor)
m_med=sum(data_hazard3$Medium)
m_major=sum(data_hazard3$Major)
m_tot=m_minor+m_med+m_major

data_hazard3$xij_minor=ifelse(data_hazard3$Minor != 0, data_hazard3$total_severity/data_hazard3$Minor,0)
data_hazard3$xij_med=ifelse(data_hazard3$Medium != 0, data_hazard3$total_severity/data_hazard3$Medium,0)
data_hazard3$xij_major=ifelse(data_hazard3$Major != 0, data_hazard3$total_severity/data_hazard3$Major,0)

Xbar_minor=1/m_minor*(sum(data_hazard3$Minor*data_hazard3$xij_minor))
Xbar_med=1/m_med*(sum(data_hazard3$Medium*data_hazard3$xij_med))
Xbar_major=1/m_major*(sum(data_hazard3$Major*data_hazard3$xij_major))
Xbar=sum(data_hazard3$total_severity)/m_tot

V_minor=1/(m_minor-1)*(sum(data_hazard3$Minor*(data_hazard3$xij_minor-Xbar_minor)^2))
V_med=1/(m_med-1)*(sum(data_hazard3$Medium*(data_hazard3$xij_med-Xbar_med)^2))
V_major=1/(m_major-1)*(sum(data_hazard3$Major*(data_hazard3$xij_major-Xbar_major)^2))
V=1/(m_tot-3)*((m_minor-1)*V_minor+(m_med-1)*V_med+(m_major-1)*V_major)
a=m_tot/(m_tot^2-m_minor^2-m_med^2-m_major^2)*((m_minor*(Xbar_minor-Xbar)^2+
                                                  m_med*(Xbar_med-Xbar)^2+m_major*(Xbar_major-Xbar)^2)-2*V)
Z_minor=m_minor/(m_minor+V/a)
Z_med=m_med/(m_med+V/a)
Z_major=m_major/(m_major+V/a)

P3_minor=3.637*(Z_minor*Xbar_minor+(1-Z_minor)*Xbar)
P3_med=9.445*(Z_med*Xbar_med+(1-Z_med)*Xbar)
P3_major=1.466*(Z_major*Xbar_major+(1-Z_major)*Xbar)
P3=P3_minor+P3_med+P3_major 

#bulman region_4
m_minor=sum(data_hazard4$Minor)
m_med=sum(data_hazard4$Medium)
m_major=sum(data_hazard4$Major)
m_tot=m_minor+m_med+m_major

data_hazard4$xij_minor=ifelse(data_hazard4$Minor != 0, data_hazard4$total_severity/data_hazard4$Minor,0)
data_hazard4$xij_med=ifelse(data_hazard4$Medium != 0, data_hazard4$total_severity/data_hazard4$Medium,0)
data_hazard4$xij_major=ifelse(data_hazard4$Major != 0, data_hazard4$total_severity/data_hazard4$Major,0)

Xbar_minor=1/m_minor*(sum(data_hazard4$Minor*data_hazard4$xij_minor))
Xbar_med=1/m_med*(sum(data_hazard4$Medium*data_hazard4$xij_med))
Xbar_major=1/m_major*(sum(data_hazard4$Major*data_hazard4$xij_major))
Xbar=sum(data_hazard1$total_severity)/m_tot

V_minor=1/(m_minor-1)*(sum(data_hazard4$Minor*(data_hazard4$xij_minor-Xbar_minor)^2))
V_med=1/(m_med-1)*(sum(data_hazard4$Medium*(data_hazard4$xij_med-Xbar_med)^2))
V_major=1/(m_major-1)*(sum(data_hazard4$Major*(data_hazard4$xij_major-Xbar_major)^2))
V=1/(m_tot-3)*((m_minor-1)*V_minor+(m_med-1)*V_med+(m_major-1)*V_major)
a=m_tot/(m_tot^2-m_minor^2-m_med^2-m_major^2)*((m_minor*(Xbar_minor-Xbar)^2+
                                                  m_med*(Xbar_med-Xbar)^2+m_major*(Xbar_major-Xbar)^2)-2*V)
Z_minor=m_minor/(m_minor+V/a)
Z_med=m_med/(m_med+V/a)
Z_major=m_major/(m_major+V/a)

P4_minor=2.475*(Z_minor*Xbar_minor+(1-Z_minor)*Xbar)
P4_med=6.427*(Z_med*Xbar_med+(1-Z_med)*Xbar)
P4_major=0.997*(Z_major*Xbar_major+(1-Z_major)*Xbar)
P4=P4_minor+P4_med+P4_major 

#bulman region_5
m_minor=sum(data_hazard5$Minor)
m_med=sum(data_hazard5$Medium)
m_major=sum(data_hazard5$Major)
m_tot=m_minor+m_med+m_major

data_hazard5$xij_minor=ifelse(data_hazard5$Minor != 0, data_hazard5$total_severity/data_hazard5$Minor,0)
data_hazard5$xij_med=ifelse(data_hazard5$Medium != 0, data_hazard5$total_severity/data_hazard5$Medium,0)
data_hazard5$xij_major=ifelse(data_hazard5$Major != 0, data_hazard5$total_severity/data_hazard5$Major,0)

Xbar_minor=1/m_minor*(sum(data_hazard5$Minor*data_hazard5$xij_minor))
Xbar_med=1/m_med*(sum(data_hazard5$Medium*data_hazard5$xij_med))
Xbar_major=1/m_major*(sum(data_hazard5$Major*data_hazard5$xij_major))
Xbar=sum(data_hazard1$total_severity)/m_tot

V_minor=1/(m_minor-1)*(sum(data_hazard5$Minor*(data_hazard5$xij_minor-Xbar_minor)^2))
V_med=1/(m_med-1)*(sum(data_hazard5$Medium*(data_hazard5$xij_med-Xbar_med)^2))
V_major=1/(m_major-1)*(sum(data_hazard5$Major*(data_hazard5$xij_major-Xbar_major)^2))
V=1/(m_tot-3)*((m_minor-1)*V_minor+(m_med-1)*V_med+(m_major-1)*V_major)
a=m_tot/(m_tot^2-m_minor^2-m_med^2-m_major^2)*((m_minor*(Xbar_minor-Xbar)^2+
                                                  m_med*(Xbar_med-Xbar)^2+m_major*(Xbar_major-Xbar)^2)-2*V)
Z_minor=m_minor/(m_minor+V/a)
Z_med=m_med/(m_med+V/a)
Z_major=m_major/(m_major+V/a)

P5_minor=2.039*(Z_minor*Xbar_minor+(1-Z_minor)*Xbar)
P5_med=5.293*(Z_med*Xbar_med+(1-Z_med)*Xbar)
P5_major=0.824*(Z_major*Xbar_major+(1-Z_major)*Xbar)
P5=P5_minor+P5_med+P5_major 

#bulman region_6
m_minor=sum(data_hazard6$Minor)
m_med=sum(data_hazard6$Medium)
m_major=sum(data_hazard6$Major)
m_tot=m_minor+m_med+m_major

data_hazard6$xij_minor=ifelse(data_hazard6$Minor != 0, data_hazard6$total_severity/data_hazard6$Minor,0)
data_hazard6$xij_med=ifelse(data_hazard6$Medium != 0, data_hazard6$total_severity/data_hazard6$Medium,0)
data_hazard6$xij_major=ifelse(data_hazard6$Major != 0, data_hazard6$total_severity/data_hazard6$Major,0)

Xbar_minor=1/m_minor*(sum(data_hazard6$Minor*data_hazard6$xij_minor))
Xbar_med=1/m_med*(sum(data_hazard6$Medium*data_hazard6$xij_med))
Xbar_major=1/m_major*(sum(data_hazard6$Major*data_hazard6$xij_major))
Xbar=sum(data_hazard6$total_severity)/m_tot

V_minor=1/(m_minor-1)*(sum(data_hazard6$Minor*(data_hazard6$xij_minor-Xbar_minor)^2))
V_med=1/(m_med-1)*(sum(data_hazard6$Medium*(data_hazard6$xij_med-Xbar_med)^2))
V_major=1/(m_major-1)*(sum(data_hazard6$Major*(data_hazard6$xij_major-Xbar_major)^2))
V=1/(m_tot-3)*((m_minor-1)*V_minor+(m_med-1)*V_med+(m_major-1)*V_major)
a=m_tot/(m_tot^2-m_minor^2-m_med^2-m_major^2)*((m_minor*(Xbar_minor-Xbar)^2+
                                                  m_med*(Xbar_med-Xbar)^2+m_major*(Xbar_major-Xbar)^2)-2*V)

Z_minor=m_minor/(m_minor+V/a)
Z_med=m_med/(m_med+V/a)
Z_major=m_major/(m_major+V/a)

P6_minor=1.147*(Z_minor*Xbar_minor+(1-Z_minor)*Xbar)
P6_med=2.951*(Z_med*Xbar_med+(1-Z_med)*Xbar)
P6_major=0.47*(Z_major*Xbar_major+(1-Z_major)*Xbar)
P6=P6_minor+P6_med+P6_major 

(P1+P2+P3+P4+P5+P6)/((531771287+222153795+417708522+45815957+69643447+9845914)*1000*1.0384^10)


#GDP in 2030 if the inflation rate is the lowest value in the 95% conf interval
A1=(531771287+222153795+417708522+45815957+69643447+9845914)*1000*1.0384*
  prod(1+prediction_1$lower[c(1:9),2])
#GDP in 2030 if the inflation rate is according to our expectation
A2=(531771287+222153795+417708522+45815957+69643447+9845914)*1000*1.0384^10
#Economic capital needed in 2020 is present value of A2-A1 in 2020 
#with the lowest inflation rate in the 95% conf interval
A3=(A2-A1)/(prod(1+prediction_1$lower[c(1:9),2]))*1.0348^-1

